from mesclasses_events_users import *
from mabasededonnee import *

#**********************************************************************************************************************************************************************************
#                                                       La gestion des événements (ajout/suppression/modification)                                                                *
#**********************************************************************************************************************************************************************************
def comfirmajout():
    suppevent = 0
    modifiercolomne = 0
    nouveaucontenu = 0
    eventasupprimer=0
    event_a_modifier=0
    eventasupprimernom=0
    nomeventamodifier=0
    nouveau_evenement = evenement(nvevent.get(),nvinterv.get(),nvauteurcontexte.get(),nvperiode.get(),modifiercolomne,nouveaucontenu,dateprecise.get(),eventasupprimer,event_a_modifier,eventasupprimernom,nomeventamodifier)
    nouveau_evenement.ajoutbd()
    affichage_apres_conexion.affichevents()
    affichage_apres_conexion.afficherintervenants()
    affichage_apres_conexion.afficherauteuretcontexte()
    affichage_apres_conexion.affichedateprecise()
    affichage_apres_conexion.afficheperiode()
    fenetreajout.destroy()

def comfirmsupprimer():
    nvevent = 0
    nvintervnvauteurcontexte = 0
    nvperiode = 0
    nvinterv = 0
    modifiercolomne = 0
    nouveaucontenu = 0
    dateprecise=0
    event_a_modifier=0
    nvauteurcontexte=0
    eventasupprimerrdate= eventasupprimerdate.get()
    eventasupprimernomm = eventasupprimernom.get()
    nomeventamodifier=0
    supprimer_evenement = evenement(nvevent,nvinterv,nvauteurcontexte,nvperiode,modifiercolomne,nouveaucontenu,dateprecise,eventasupprimerrdate,event_a_modifier,eventasupprimernomm,nomeventamodifier)
    supprimer_evenement.supprimerbd()
    affichage_apres_conexion.affichevents()
    affichage_apres_conexion.afficherintervenants()
    affichage_apres_conexion.afficherauteuretcontexte()
    affichage_apres_conexion.affichedateprecise()
    affichage_apres_conexion.afficheperiode()
    fenetresup.destroy()

def comfirmodif():
    event_a_modifierdate = dateeventamodifier.get()
    nvevent = 0
    nvintervnvauteurcontexte = 0
    nvperiode = 0
    nvinterv = 0
    modifiercolomne=modifier_colomne.get()
    nouveaucontenu=nvcontenu.get()
    eventasupp=0
    nvauteurcontexte=0
    dateprecise=0
    eventasupprimernom=0
    nomeventamodifierr=nomeventamodifier.get()
    modifier_evenement = evenement(nvevent,nvinterv,nvauteurcontexte,nvperiode,modifiercolomne,nouveaucontenu,dateprecise,eventasupp,event_a_modifierdate,eventasupprimernom,nomeventamodifierr)
    modifier_evenement.modifierbd()
    affichage_apres_conexion.affichevents()
    affichage_apres_conexion.afficherintervenants()
    affichage_apres_conexion.afficherauteuretcontexte()
    affichage_apres_conexion.affichedateprecise()
    affichage_apres_conexion.afficheperiode()
    fenetremodif.destroy()


#**********************************************************************************************************************************************************************************
#                                                       La phase aprés connexion
#**********************************************************************************************************************************************************************************
class affichage_apres_conexion:

    def affichevents():
        global labelframeactuel
        labelframeactuel =  str("labelFrame_events")
        resultat = c.execute ("SELECT NomsEvents FROM events")
        fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
        fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
        labelFrame_events = LabelFrame(fenetre, text="Les événements",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelFrame_events.pack(fill="both", expand="yes")
        labelFrame_events.place(height=770, width=182.52,x=5,y=0)
        for i in resultat:
            Label(labelFrame_events, text=i, font=fontStyle,fg="white",bg='#3E3E3E').pack()
            labelFrame_events.place(height=770, width=182.52,x=5,y=0)

    def afficherintervenants():
            global labelframeactuel
            labelframeactuel = str("labelFrame_intervenant")
            resultat = c.execute ("SELECT  Intervenants FROM events")
            fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
            fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
            labelFrame_intervenant = LabelFrame(fenetre, text="Les intervenants",fg='white',font=fontStylebis,bg='#3E3E3E',padx=5, pady=20)
            labelFrame_intervenant.pack(fill="both", expand="yes")
            labelFrame_intervenant.place(height=770, width=182.52,x=182.52,y=0)
            for j in resultat:
                Label(labelFrame_intervenant, text=j, font=fontStyle,fg="white",bg='#3E3E3E').pack()
                labelFrame_intervenant.place(height=770, width=182.52,x=182.52,y=0)

    def afficherauteuretcontexte():
            global labelframeactuel
            labelframeactuel = str("labelFrame_auteurcontexte")
            resultat = c.execute ("SELECT  ContexteETauteur FROM events")
            fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
            fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
            labelFrame_auteurcontexte = LabelFrame(fenetre, text="Les contextes & auteurs",font=fontStylebis,fg='white', bg='#3E3E3E',padx=5, pady=20)
            labelFrame_auteurcontexte.pack(fill="both", expand="yes")
            labelFrame_auteurcontexte.place(height=770, width=182.52,x=365.04,y=0)
            for k in resultat:
                Label(labelFrame_auteurcontexte, text=k, font=fontStyle,fg="white",bg='#3E3E3E').pack()
                labelFrame_auteurcontexte.place(height=770, width=182.52,x=365.04,y=0)

    def affichedateprecise():
        global labelframeactuel
        labelframeactuel = str("labelframedateprecise")
        resultat = c.execute ("SELECT DatePrecise FROM events")
        fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
        fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
        labelfraemedateprecise = LabelFrame(fenetre, text="Les dates précises",font=fontStylebis, bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelfraemedateprecise.pack(fill="both", expand="yes")
        labelfraemedateprecise.place(height=770, width=182.52,x=547.56,y=0)
        for w in resultat:
                Label(labelfraemedateprecise, text=w, font=fontStyle,fg="white",bg='#3E3E3E').pack()
                labelfraemedateprecise.place(height=770, width=182.52,x=547.56,y=0)

    def afficheperiode():
        global labelframeactuel
        labelframeactuel = str("labelframeperiode")
        resultat = c.execute ("SELECT Periode FROM events")
        fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
        fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
        labelframeperiode = LabelFrame(fenetre, text="Les périodes",font=fontStylebis, bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelframeperiode.pack(fill="both", expand="yes")
        labelframeperiode.place(height=770, width=182.52,x=730.08,y=0)
        for z in resultat:
                Label(labelframeperiode, text=z, font=fontStyle,fg="white",bg='#3E3E3E').pack()
                labelframeperiode.place(height=770, width=182.52,x=730.08,y=0)

    def ajouter_event():
        global nvevent
        global nvinterv
        global nvauteurcontexte
        global nvperiode
        global dateprecise
        global fenetreajout
        fontStyle = tkFont.Font(family="Courier New TUR", size=9,weight='normal')
        fenetreajout = Toplevel(fenetre)
        fenetreajout.geometry("550x300")
        fenetreajout.title("Ajout d'un evenement")
        fenetreajout.resizable(False,False)
        fenetreajout.configure(bg='#3E3E3E')
        nvevent = StringVar()
        champ_nvevent = Entry(fenetreajout, textvariable=nvevent,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_nvevent.focus_set()
        champ_nvevent.pack()
        champ_nvevent.place(height=20, width=300,y=70,x=200)
        ae=Label(fenetreajout,text="Nom de l'evenement",font=fontStyle,bg='#3E3E3E',fg='white')
        ae.place(x=0,y=70)
        nvinterv = StringVar()
        champ_nvinterv = Entry(fenetreajout, textvariable=nvinterv,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_nvinterv.focus_set()
        champ_nvinterv.pack()
        champ_nvinterv.place(height=20, width=300,y=120,x=200)
        ai=Label(fenetreajout,text="Le ou les intervenant(s)",font=fontStyle,bg='#3E3E3E',fg='white')
        ai.place(x=0,y=120)
        nvauteurcontexte = StringVar()
        champ_nvauteurcontexte = Entry(fenetreajout, textvariable=nvauteurcontexte,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_nvauteurcontexte.focus_set()
        champ_nvauteurcontexte.pack()
        champ_nvauteurcontexte.place(height=20, width=300,y=170,x=200)
        ai=Label(fenetreajout,text="Le contexte & le(s) auteur(s)\n(max.180 caractéres)",font=fontStyle,bg='#3E3E3E',fg='white')
        ai.place(x=0,y=170)
        ai=Label(fenetreajout,text="Dans",font=fontStyle,bg='#3E3E3E',fg='white')
        ai.place(x=0,y=20)
        periodepossib=["1 semaine","2 semaines","3 semaines", "1 mois","2 mois","3 mois","4 mois","5 mois","6 mois","7 mois","8 mois","9 mois","10 mois","11 mois","1 an","autre"]
        nvperiode = ttk.Combobox(fenetreajout, values=periodepossib,font=fontStyle)
        nvperiode.current(0)
        nvperiode.pack(pady=20)
        dp=Label(fenetreajout,text="Date precise (jj/mm/aaaa)",font=fontStyle,bg='#3E3E3E',fg='white')
        dp.place(x=0,y=220)
        dateprecise = StringVar()
        dpt = Entry(fenetreajout, textvariable = dateprecise ,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        dpt.focus_set()
        dpt.pack()
        dpt.place(height=20, width=300,y=220,x=200)
        ok = Button(fenetreajout, text="OK",font=fontStyle,command=comfirmajout,bg='#FF9701')
        ok.place(y=272,width=150,x=220)

    def supprimer():
        global  eventasupprimerdate
        global  fenetresup
        global  eventasupprimernom
        fontStyle = tkFont.Font(family="Courier New TUR", size=9,weight='normal')
        fenetresup = Toplevel(fenetre)
        fenetresup.geometry("420x70")
        fenetresup.configure(bg='#3E3E3E')
        fenetresup.title("Date et nom de l'événement à supprimer")
        fenetresup.resizable(False,False)
        cd=Label(fenetresup,text="Date",bg="#3E3E3E",fg="white",font=fontStyle)
        cd.place(x=0,y=10)
        eventasupprimerdate = StringVar()
        champ_supprimerdate = Entry(fenetresup, textvariable=eventasupprimerdate,bg='#BFC9CA',font=fontStyle,fg="#34495E")
        champ_supprimerdate.focus_set()
        champ_supprimerdate.pack()
        champ_supprimerdate.place(height=20, width=150,y=10,x=40)
        cn=Label(fenetresup,text="Nom",bg="#3E3E3E",fg="white",font=fontStyle)
        cn.place(x=0,y=40)
        eventasupprimernom = StringVar()
        champ_supprimernom = Entry(fenetresup, textvariable=eventasupprimernom,bg='#BFC9CA',font=fontStyle,fg="#34495E")
        champ_supprimernom.focus_set()
        champ_supprimernom.pack()
        champ_supprimernom.place(height=20, width=150,y=40,x=40)
        oksupp = Button(fenetresup, text="OK",command=comfirmsupprimer,bg="#FF9701",font=fontStyle)
        oksupp.pack()
        oksupp.place(x=250,y=40,height=20, width=70)

    def modifier_event():
        global modifier_colomne
        global nvcontenu
        global fenetremodif
        global dateeventamodifier
        global nomeventamodifier
        fontStyle = tkFont.Font(family="Courier New TUR", size=9,weight='normal')
        fenetremodif = Toplevel(fenetre)
        fenetremodif.geometry("380x150")
        fenetremodif.title("Modification d'un événement")
        fenetremodif.configure(bg='#3E3E3E')
        fenetremodif.resizable(False,False)
        dateeventamodifier = StringVar()
        champ_indice_modifier = Entry(fenetremodif, textvariable=dateeventamodifier,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_indice_modifier.focus_set()
        champ_indice_modifier.pack()
        champ_indice_modifier.place(height=20, width=143,y=10,x=128)
        cim=Label(fenetremodif,text="Date de l'événement",bg="#3E3E3E",fg="white",font=fontStyle)
        cim.place(x=5,y=10)
        nomeventamodifier = StringVar()
        champ_nom_modifier = Entry(fenetremodif, textvariable=nomeventamodifier,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_nom_modifier.focus_set()
        champ_nom_modifier.pack()
        champ_nom_modifier.place(height=20, width=143,y=35,x=128)
        nem=Label(fenetremodif,text="Nom de l'événement",bg="#3E3E3E",fg="white",font=fontStyle)
        nem.place(x=5,y=35)
        ccm=Label(fenetremodif,text="Colonne",bg="#3E3E3E",fg="white",font=fontStyle)
        ccm.place(x=5,y=60)
        colomnpossib=["NomsEvents", "Intervenants","ContexteETauteur","DatePrecise","Periode"]
        modifier_colomne = ttk.Combobox(fenetremodif, values=colomnpossib,font=fontStyle)
        modifier_colomne.current(0)
        modifier_colomne.pack(pady=60,padx=128)
        nvcontenu = StringVar()
        champ_nvcontenu = Entry(fenetremodif, textvariable=nvcontenu,bg='#BFC9CA',fg='#34495E',font=fontStyle)
        champ_nvcontenu.focus_set()
        champ_nvcontenu.pack()
        champ_nvcontenu.place(height=20, width=143,y=85,x=128)
        cnv=Label(fenetremodif,text="Nouveau contenu",bg="#3E3E3E",fg="white",font=fontStyle)
        cnv.place(x=5,y=85)
        okmodif = Button(fenetremodif, text="OK",command=comfirmodif,bg="#FF9701",font=fontStyle)
        okmodif.pack()
        okmodif.place(x=170,y=120,height=20, width=90)

    def filtrer(choix):
        fontStyle = tkFont.Font(family="Courier New TUR", size=8,weight='bold')
        fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
        if choix == 10:
            periodee = ("1 semaine", )
        elif choix == 20:
            periodee = ("2 semaines", )
        elif choix == 30:
            periodee = ("3 semaines", )
        elif choix == 40:
            periodee = ("1 mois", )
        elif choix == 50:
            periodee = ("2 mois", )
        elif choix == 60:
            periodee = ("3 mois", )
        elif choix == 70:
            periodee = ("4 mois", )
        elif choix == 80:
            periodee = ("5 mois", )
        elif choix == 90:
            periodee = ("6 mois", )
        elif choix == 100:
            periodee = ("7 mois", )
        elif choix == 110:
            periodee = ("8 mois", )
        elif choix == 120:
            periodee = ("9 mois", )
        elif choix == 130:
            periodee = ("10 mois", )
        elif choix == 140:
            periodee = ("11 mois", )
        elif choix == 150:
            periodee = ("1 an", )
        elif choix == 160:
            periodee = ("autre", )

        resultat = c.execute ("SELECT NomsEvents FROM events WHERE Periode = ?",periodee)
        resultat = c.fetchall()
        labelFrame_events = LabelFrame(fenetre, text="Les événements",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelFrame_events.pack(fill="both", expand="yes")
        labelFrame_events.place(height=770, width=182.52,x=5,y=0)
        for h in resultat:
            Label(  labelFrame_events, text=h, font=fontStyle,fg='white',bg='#3E3E3E').pack()

        resultat = c.execute ("SELECT Intervenants FROM events WHERE Periode = ?",periodee)
        resultat = c.fetchall()
        labelFrame_intervenant = LabelFrame(fenetre, text="Les intervenants",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelFrame_intervenant.pack(fill="both", expand="yes")
        labelFrame_intervenant.place(height=770, width=182.52,x=182.52,y=0)
        for p in resultat:
            Label(  labelFrame_intervenant, text=p, font=fontStyle,fg='white',bg='#3E3E3E').pack()

        resultat = c.execute ("SELECT ContexteETauteur FROM events WHERE Periode = ?",periodee)
        resultat = c.fetchall()
        labelFrame_auteurcontexte = LabelFrame(fenetre, text="Les contextes & auteurs",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelFrame_auteurcontexte.pack(fill="both", expand="yes")
        labelFrame_auteurcontexte.place(height=770, width=182.52,x=365.04,y=0)
        for m in resultat:
            Label(  labelFrame_auteurcontexte, text=m, font=fontStyle,fg='white',bg='#3E3E3E').pack()

        resultat = c.execute ("SELECT DatePrecise FROM events WHERE Periode = ?",periodee)
        resultat = c.fetchall()
        labelfraemedateprecise = LabelFrame(fenetre, text="Les dates précises",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelfraemedateprecise.pack(fill="both", expand="yes")
        labelfraemedateprecise.place(height=770, width=182.52,x=547.56,y=0)
        for y in resultat:
            Label(  labelfraemedateprecise, text=y, font=fontStyle,fg='white',bg='#3E3E3E').pack()

        resultat = c.execute ("SELECT Periode FROM events WHERE Periode = ?",periodee)
        resultat = c.fetchall()
        labelframeperiode = LabelFrame(fenetre, text="Les périodes",font=fontStylebis,bg='#3E3E3E',fg='white',padx=5, pady=20)
        labelframeperiode.pack(fill="both", expand="yes")
        labelframeperiode.place(height=770, width=182.52,x=730.08,y=0)
        for x in resultat:
            Label(  labelframeperiode, text=x, font=fontStyle,fg='white',bg='#3E3E3E').pack()

    def filtrage():
        choix=choix_filtre.get()
        affichage_apres_conexion.filtrer(choix)

    def viderbdd():
        reponse = messagebox.askquestion(title="Vider toute la base de données", message="êtes-vous sûr de vider la base de données ?")
        if reponse == "yes":
            c.execute("DELETE FROM events WHERE NomsEvents=NomsEvents")
            conn.commit()
            affichage_apres_conexion.affichevents()
            affichage_apres_conexion.afficherintervenants()
            affichage_apres_conexion.afficherauteuretcontexte()
            affichage_apres_conexion.affichedateprecise()
            affichage_apres_conexion.afficheperiode()

    def annulerfiltrage():
        affichage_apres_conexion.affichevents()
        affichage_apres_conexion.afficherintervenants()
        affichage_apres_conexion.afficherauteuretcontexte()
        affichage_apres_conexion.affichedateprecise()
        affichage_apres_conexion.afficheperiode()

    # la fenetre aprés la connexion
    def fenetregestionevent(statutmaire,statuthorsmaire):
        global fenetre
        fenetre = Toplevel(authentification)
        fenetre.iconbitmap('home.ico')
        if statutmaire == 1 and statuthorsmaire == 0:
            fenetre.title('Espace admin')
        elif statutmaire == 0 and statuthorsmaire == 1:
            fenetre.title('Espace hors admin')
        fenetre.geometry('1097x780')
        fenetre.configure(bg = '#3E3E3E')

        fontStyle = tkFont.Font(family="Courier New TUR", size=7,weight='bold')

        #Labelframe pour tous les boutons
        labelFrame_buttons = LabelFrame(fenetre, padx=5, pady=20, bg='#656765')
        labelFrame_buttons.pack(fill="both", expand="yes")
        labelFrame_buttons.place(height=780, width=170,x=927)

        #ESPACE ADMIN
        if statutmaire == 1 and statuthorsmaire == 0:
            labelgestion = Label(labelFrame_buttons,text="GERER LES EVENEMENTS",bg='#FF9701',fg='#3E3E3E',width=200,height=4,font=fontStyle).pack(pady=10)
            ajouter_event_button = Button(labelFrame_buttons, text="AJOUT UN EVENEMENT",command=affichage_apres_conexion.ajouter_event,width=200,bg='#3E3E3E',fg='white',font=fontStyle,height=2)
            ajouter_event_button.pack()
            supp_button = Button(labelFrame_buttons, text="SUPPRIMER UN EVENEMENT",command=affichage_apres_conexion.supprimer,width=200,bg='#3E3E3E',fg='white',font=fontStyle,height=2)
            supp_button.pack()
            modif_button = Button(labelFrame_buttons, text="MODIFIER UN EVENEMENT",command=affichage_apres_conexion.modifier_event,width=200,bg='#3E3E3E',fg='white',font=fontStyle,height=2)
            modif_button.pack()

        #PARTIE COMMUNE ENTRE ESPACE ADMIN ET ESPACE HORS ADMIN
        global choix_filtre
        choix_filtre= IntVar()
        #Filtrage des événements
        labelfiltre = Label(labelFrame_buttons,text="FILTRER PAR PERIODES",width=200,bg='#FF9701',fg='#3E3E3E',font=fontStyle,height=4).pack(pady=10)
        case1 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 10,fg='white',bg='#656765',text="1 semaine   ",selectcolor='#FF9701',font=fontStyle).pack()
        case2 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 20,fg='white',bg='#656765',text="2 semaines  ",font=fontStyle,selectcolor='#FF9701').pack()
        case3 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 30,fg='white',bg='#656765',text="3 semaines  ",selectcolor='#FF9701',font=fontStyle).pack()
        case4 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 40,fg='white',bg='#656765',text="1 mois        ",selectcolor='#FF9701',font=fontStyle).pack()
        case5 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 50,fg='white',bg='#656765',text="2 mois        ",font=fontStyle,selectcolor='#FF9701').pack()
        case6 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 60,fg='white',bg='#656765',text="3 mois        ",selectcolor='#FF9701',font=fontStyle).pack()
        case7 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 70,fg='white',bg='#656765',text="4 mois        ",selectcolor='#FF9701',font=fontStyle).pack()
        case8 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 80,fg='white',bg='#656765',text="5 mois        ",selectcolor='#FF9701',font=fontStyle).pack()
        case9 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 90,fg='white',bg='#656765',text="6 mois        ",font=fontStyle,selectcolor='#FF9701').pack()
        case10 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 100,fg='white',bg='#656765',text="7 mois       ",selectcolor='#FF9701',font=fontStyle).pack()
        case11 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 110,fg='white',bg='#656765',text="8 mois       ",selectcolor='#FF9701',font=fontStyle).pack()
        case12= Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 120,fg='white',bg='#656765',text="9 mois        ",selectcolor='#FF9701',font=fontStyle).pack()
        case13 = Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 130,fg='white',bg='#656765',text="10 mois      ",font=fontStyle,selectcolor='#FF9701').pack()
        case14= Radiobutton (labelFrame_buttons,variable = choix_filtre, value =140,fg='white',bg='#656765',text="11 mois       ",selectcolor='#FF9701',font=fontStyle).pack()
        case15= Radiobutton (labelFrame_buttons,variable = choix_filtre, value = 150,fg='white',bg='#656765',text="1 an            ",selectcolor='#FF9701',font=fontStyle).pack()
        case16= Radiobutton (labelFrame_buttons,variable = choix_filtre , value =160,fg='white',bg='#656765',text="autre           ",selectcolor='#FF9701',font=fontStyle).pack()
        filtre_button = Button(labelFrame_buttons,text="CONFIRMER LE FILTRAGE",command=affichage_apres_conexion.filtrage,width=200,bg='#3E3E3E',fg='white',font=fontStyle,height=2).pack()
        annuler_filtre_button = Button(labelFrame_buttons,text="ANNULER LE FILTRAGE",command=affichage_apres_conexion.annulerfiltrage,width=200,bg='#3E3E3E',fg='white',font=fontStyle,height=2).pack()
        affichage_apres_conexion.affichevents()
        affichage_apres_conexion.afficherintervenants()
        affichage_apres_conexion.afficherauteuretcontexte()
        affichage_apres_conexion.affichedateprecise()
        affichage_apres_conexion.afficheperiode()
        #ESPACE ADMIN
        if statutmaire == 1 and statuthorsmaire == 0:
            labelvidage = Label(labelFrame_buttons,text="VIDER LA BASE DE DONNEES",bg='#FF9701',fg='#3E3E3E',width=200,font=fontStyle,height=4).pack(pady=10)
            vidagebutton = Button(labelFrame_buttons,text="TOUT EFFACER",command=affichage_apres_conexion.viderbdd,width=200,bg='#3E3E3E',fg='red',font=fontStyle,height=2).pack()

        fenetre.resizable(False,False)
        fenetre.mainloop()
        conn.close()

    def okauthentification():
        sm=statutmaire.get()
        shm=statuthorsmaire.get()
        passwordd = password.get()
        identifiant=nom.get()
        nvutilisateur = utilisateur(shm,sm,identifiant,passwordd)
        if (sm == 1 and shm == 0 and str(passwordd) == "admin" and  str(identifiant) == "je suis admin") or (sm == 0 and shm == 1 and str(passwordd) == "nonadmin" and  str(identifiant) == "je ne suis pas admin") :
            errorconn = Label(authentification,text = 'Vérifiez votre mot de passe ou la case séléctionnée!',bg='#FF9701',fg="#FF9701",font=fontStyle)
            errorconn.place(x=160,y=350)
            errorconn = Label(authentification,text = 'Vérifiez votre mot de passe !',bg='#FF9701',fg="#FF9701",font=fontStyle)
            errorconn.place(x=160,y=350)
            affichage_apres_conexion.fenetregestionevent(sm,shm)
        elif (sm == 1 and shm == 0 and str(passwordd) != "admin") or (sm == 0 and shm == 1 and str(passwordd) != "nonadmin"):
            errorconn = Label(authentification,text = 'Vérifiez votre identifiant ou le mot de passe ou la case séléctionnée!',bg='#FF9701',fg="red",font=fontStyle)
            errorconn.place(x=100,y=350)



#**********************************************************************************************************************************************************************************
#                                                               La phase avant la connexion                                                                                       *
#**********************************************************************************************************************************************************************************
class affichage_avant_connexion:
    def main():
        global authentification
        global statutmaire
        global statuthorsmaire
        global password
        global nom
        global fontStyle
        global fontStylebis
        authentification = Tk()
        authentification.title("Connexion")
        authentification.geometry('600x500')
        authentification.iconbitmap('user.ico')
        authentification.configure(bg = '#3E3E3E')
        fontStyle = tkFont.Font(family="Courier New TUR", size=9,weight='bold')
        fontStylebis = tkFont.Font(family="Courier New TUR", size=9,weight='normal')
        moncanvas = Canvas (authentification,bg="#FF9701",height=450, width=600,bd=-5).pack(pady=5)
        np = Label(authentification,text = 'Identifiant',bg='#FF9701',fg="#3E3E3E",font=fontStyle)
        np.place(x=265,y=50)
        nom= StringVar()
        nom = Entry(authentification, textvariable= np,fg="#3E3E3E",font=fontStylebis)
        nom.place(x=73,y=100,width=450)
        mdp = Label(authentification, text = 'Mot de passe ',bg='#FF9701',fg="#3E3E3E",font=fontStyle)
        mdp.place(x=264,y=150)
        password= StringVar()
        champ = Entry(authentification, textvariable= password,fg="#3E3E3E",font=fontStylebis,show="*")
        champ.place(x=73,y=200,width=450)
        entrer = Button(authentification,text="Se connecter",command=affichage_apres_conexion.okauthentification,bg="#3E3E3E",fg="white",font=fontStyle)
        entrer.place(x=260,y=390,width=100)
        statutmaire = IntVar()
        statutmairecheck = Checkbutton(authentification,variable=statutmaire,bg='#FF9701',fg="#3E3E3E")
        statuthorsmaire = IntVar()
        statuthorsmairecheck = Checkbutton(authentification,variable=statuthorsmaire,bg='#FF9701',fg="#3E3E3E")
        statutmairecheck.place(x = 360, y = 290)
        statuthorsmairecheck.place(x = 140, y = 290)
        statutmairecheck.config(text = "Espace admin",font=fontStyle)
        statuthorsmairecheck.config(text = "Espace hors admin",font=fontStyle)
        proprietaire = Label(authentification,text = 'ISTY - IATIC 3 - 2020/2021 © Tous les droits sont réservés. Conçu et développé par SLIM KHIARI',bg='#3E3E3E',fg="white",font=fontStylebis).place(y=465,x=23)
        authentification.resizable(False, False)
        authentification.mainloop()

affichage_avant_connexion.main()

from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter.font as tkFont
from mabasededonnee import *
import tkinter as tk


class evenement:
    global liste_evenements
    global liste_intervenants
    global liste_auteurcontexte
    global liste_periode
    global liste_dateprecise
    liste_evenements=[]
    liste_intervenants=[]
    liste_auteurcontexte=[]
    liste_periode=[]
    liste_dateprecise=[]

    def __init__(self,event_nom,event_intervenant,event_auteurcontexte,event_periode,modifiercolomne,nouveaucontenu,dateprecise,eventasupprimer,event_a_modifier,eventasupprimernom,nomeventamodifier):
        self.nvevent = event_nom
        self.nvinterv = event_intervenant
        self.nvauteurcontexte = event_auteurcontexte
        self.nvperiode = event_periode
        self.modifiercolomne = modifiercolomne
        self.nouveaucontenu = nouveaucontenu
        self.dateprecise=dateprecise
        self.eventasupprimer = eventasupprimer
        self.event_a_modifier=event_a_modifier
        self.eventasupprimernom = eventasupprimernom
        self.nomeventamodifier = nomeventamodifier

    def ajouter(self):
        liste_intervenants.append(self.nvinterv)
        liste_evenements.append(self.nvevent)
        liste_auteurcontexte.append(self.nvauteurcontexte)
        liste_periode.append(self.nvperiode)
        liste_dateprecise.append(self.dateprecise)

    def ajoutbd(self):
        unevent = {"NomsEvents":str(self.nvevent),"Intervenants":str(self.nvinterv),"Periode":str(self.nvperiode),"ContexteETauteur":str(self.nvauteurcontexte),"DatePrecise":str(self.dateprecise)}
        c.execute("INSERT INTO events VALUES (:NomsEvents,:Intervenants,:Periode,:ContexteETauteur,:DatePrecise)",unevent)
        conn.commit()

    def supprimerbd(self):
        sql = "DELETE FROM events WHERE DatePrecise=? AND NomsEvents=?"
        dateeventdb = self.eventasupprimer
        eventasupprimernoom=self.eventasupprimernom
        c.execute(sql, (dateeventdb, eventasupprimernoom, ))
        conn.commit()

    def modifierbd(self):
        if self.modifiercolomne == "NomsEvents":
            c.execute("""UPDATE events SET NomsEvents=? WHERE DatePrecise=? AND NomsEvents=?""", (self.nouveaucontenu , self.event_a_modifier, self.nomeventamodifier))
            conn.commit()
        elif self.modifiercolomne == "Intervenants":
                c.execute("""UPDATE events SET Intervenants=? WHERE DatePrecise=? AND NomsEvents=?""", (self.nouveaucontenu , self.event_a_modifier, self.nomeventamodifier))
                conn.commit()
        elif self.modifiercolomne == "ContexteETauteur":
                c.execute("""UPDATE events SET ContexteETauteur=? WHERE DatePrecise=? AND NomsEvents=?""", (self.nouveaucontenu , self.event_a_modifier, self.nomeventamodifier))
                conn.commit()
        elif self.modifiercolomne == "DatePrecise":
                c.execute("""UPDATE events SET DatePrecise=? WHERE DatePrecise=? AND NomsEvents=?""", (self.nouveaucontenu , self.event_a_modifier, self.nomeventamodifier))
                conn.commit()
        elif self.modifiercolomne == "Periode":
                c.execute("""UPDATE events SET Periode=? WHERE DatePrecise=? AND NomsEvents=?""", (self.nouveaucontenu , self.event_a_modifier, self.nomeventamodifier))
                conn.commit()

class utilisateur:
    def __init__(self,util_statutmaire,util_statuthorsmaire,util_nom,util_password):
        self.statutmaire = util_statutmaire
        self.statuthorsmaire = util_statuthorsmaire
        self.nom = util_nom
        self.password = util_password


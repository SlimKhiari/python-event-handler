import sqlite3

global c

conn = sqlite3.connect("event.db")
c = conn.cursor()

c.execute("""
CREATE TABLE IF NOT EXISTS events
(
    NomsEvents text,
    Intervenants text,
    Periode text,
    ContexteETauteur text,
    DatePrecise text
)
 """)


